package tn.esprit.spring.khademsouhaila.Entites;

public enum option {
        GAMIX,SE,SIM,NIDS
}
