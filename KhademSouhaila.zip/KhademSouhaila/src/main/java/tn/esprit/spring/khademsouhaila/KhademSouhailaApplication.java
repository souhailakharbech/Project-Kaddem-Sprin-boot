package tn.esprit.spring.khademsouhaila;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KhademSouhailaApplication {

    public static void main(String[] args) {
        SpringApplication.run(KhademSouhailaApplication.class, args);
    }

}
