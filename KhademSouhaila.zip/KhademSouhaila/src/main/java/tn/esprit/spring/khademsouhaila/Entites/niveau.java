package tn.esprit.spring.khademsouhaila.Entites;

public enum niveau {
    JUMIOR,SENIOR,EXPERT ;
}
