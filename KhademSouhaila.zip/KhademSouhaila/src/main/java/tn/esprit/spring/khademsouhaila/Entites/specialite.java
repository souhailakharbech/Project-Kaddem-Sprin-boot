package tn.esprit.spring.khademsouhaila.Entites;

public enum specialite {
    IA,RESEAU,CLOUD,SECURITE
}
