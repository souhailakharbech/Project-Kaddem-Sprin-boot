package tn.esprit.spring.khademsouhaila.Controller;

public class DetailsEquipeController {
}
