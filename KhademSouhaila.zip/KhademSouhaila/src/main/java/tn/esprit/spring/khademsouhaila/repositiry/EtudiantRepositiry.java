package tn.esprit.spring.khademsouhaila.repositiry;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import tn.esprit.spring.khademsouhaila.Entites.Etudiant;
import tn.esprit.spring.khademsouhaila.Entites.niveau;
import tn.esprit.spring.khademsouhaila.Entites.specialite;

import java.util.List;
@Repository

public interface EtudiantRepositiry extends JpaRepository <Etudiant,Long> {
   // List<Etudiant>findByDepartementidDepart(Long idDepart);
    //List<Etudiant>findByEquipeNiveau(niveau n);


    //séléctionner la liste des étudiants dont les contrats de spécialité sécurité (à corriger)
 //  @Query("SELECT e FROM Etudiant e, Contrat c where e.idEtudiant= c.e.idEtudiant and c.specialite ='SECURITE'")
   // List<Etudiant> retrieveEtudiantsBySpecialiteContrat(@Param("specialite") specialite specialite);

}
