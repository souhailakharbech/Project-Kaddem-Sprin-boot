package tn.esprit.spring.khademsouhaila.Services;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tn.esprit.spring.khademsouhaila.Entites.University;
import tn.esprit.spring.khademsouhaila.repositiry.UniversityRepositiry;

import java.util.List;
@Service
@Slf4j
@AllArgsConstructor

public class UniversityService implements IUniversityService{
    UniversityRepositiry universityRepositiry;
    @Override
    public List<University> retrieveAllUniversity() {

        return universityRepositiry.findAll();
    }

    @Override
    public University addUniversity(University u) {

        return universityRepositiry.save(u);
    }

    @Override
    public University updateUniversity(University u) {

        return universityRepositiry.save(u);
    }

    @Override
    public University retrieveUniversity(Integer idUniv) {

        return universityRepositiry.findById(idUniv.intValue()).get();
    }

    @Override
    public void deleteUniversity(Integer idUniv) {
        universityRepositiry.deleteById(idUniv.intValue());

    }
}
