package tn.esprit.spring.khademsouhaila.Services;


import tn.esprit.spring.khademsouhaila.Entites.Etudiant;

import java.util.List;

public interface IEtudiantService  {
    List<Etudiant> retrieveAllEtudiants();

    Etudiant addEtudiant(Etudiant e);

    Etudiant updateEtudiant (Etudiant e);

    Etudiant retrieveEtudiant (Long idEtudiant);

    void deleteEtudiant(Long idEtudiant);
}
