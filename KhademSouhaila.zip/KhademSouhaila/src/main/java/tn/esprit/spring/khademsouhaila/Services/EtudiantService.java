package tn.esprit.spring.khademsouhaila.Services;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import tn.esprit.spring.khademsouhaila.Entites.Department;
import tn.esprit.spring.khademsouhaila.Entites.Etudiant;
import tn.esprit.spring.khademsouhaila.repositiry.DepartementRepositiry;
import tn.esprit.spring.khademsouhaila.repositiry.EtudiantRepositiry;

import java.util.List;

@Service
@Slf4j    //?????
@AllArgsConstructor //==@RequiredArgsConstructor


public class EtudiantService implements IEtudiantService{
    //on peut faire une annotation @Autowired ici pour injecter la dep ou bien on ajoute @AllargsConstructor
    EtudiantRepositiry etudiantRepositiry;
    //à corrigé
    DepartementRepositiry departementRepositiry;
    @Override
    public List<Etudiant> retrieveAllEtudiants() {

        return etudiantRepositiry.findAll();
    }
    ////à corigé
    public void assignEtudiantToDepartment(Long idEtudiant,Integer idDepart){
     Etudiant et = etudiantRepositiry.findById(idEtudiant).get();
    Department d = departementRepositiry.findById(idDepart).get();
    et.setDepartment(d);
    etudiantRepositiry.save(et);
    }

    @Override
    public Etudiant addEtudiant(Etudiant e) {

        return etudiantRepositiry.save(e);
    }

    @Override
    public Etudiant updateEtudiant(Etudiant e) {

        return etudiantRepositiry.save(e);
    }

    @Override
    public Etudiant retrieveEtudiant(Long idEtudiant) {

        return etudiantRepositiry.findById(idEtudiant.longValue()).get();
    }

    @Override
    public void deleteEtudiant(Long idEtudiant) {
        etudiantRepositiry.deleteById(idEtudiant.longValue());

    }
}
