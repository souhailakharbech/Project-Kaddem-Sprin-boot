package tn.esprit.spring.khademsouhaila.Services;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tn.esprit.spring.khademsouhaila.Entites.Contrat;
import tn.esprit.spring.khademsouhaila.Entites.Etudiant;
import tn.esprit.spring.khademsouhaila.repositiry.ContratRepositiry;

import java.util.List;
@Service
@Slf4j
@AllArgsConstructor

public class ContratService implements IContratService{
    ContratRepositiry contratRepositiry;
    @Override
    public List<Contrat> retrieveAllContrat() {
        return contratRepositiry.findAll();
    }

    @Override
    public Contrat addContrat(Contrat c) {
        return contratRepositiry.save(c);
    }

    @Override
    public Contrat updateContrat(Contrat c) {

        return contratRepositiry.save(c);
    }

    @Override
    public Contrat retrieveContrat(Integer idContrat) {

        return contratRepositiry.findById(idContrat.intValue()).get();
    }

    @Override
    public void deleteContrat(Integer idContrat) {
        contratRepositiry.deleteById(idContrat.intValue());

    }
}
