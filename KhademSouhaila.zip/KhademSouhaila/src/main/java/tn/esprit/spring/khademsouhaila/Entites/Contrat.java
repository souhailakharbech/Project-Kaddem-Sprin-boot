package tn.esprit.spring.khademsouhaila.Entites;

import com.fasterxml.jackson.databind.DatabindException;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

import lombok.*;


@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Contrat implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="idContrat")
    private Integer idContrat; // Clé primaire
    @Temporal (TemporalType.DATE)
    private Date dateDebutContrat;
    @Temporal (TemporalType.DATE)
    private Date dateFinContrat;
    private Boolean archive;
    private Integer montantContart;

    private String nomE;
    @Enumerated(EnumType.STRING)
    private specialite specialite;
    @ManyToOne
    Etudiant etudiant;
}

